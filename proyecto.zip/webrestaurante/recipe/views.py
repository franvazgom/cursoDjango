from django.shortcuts import render, get_object_or_404, get_list_or_404
from .models import Recipe
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse, reverse_lazy


class RecipeDeleteView(DeleteView):
    model = Recipe
    success_url = reverse_lazy('recipes:recipes')


class RecipeUpdateView(UpdateView):
    model = Recipe
    fields = ['title', 'content', 'order']
    template_name_suffix = '_update_form'

    def get_success_url(self):
        return reverse_lazy("recipes:update", args=[self.object.id]) + '?ok'


class RecipeCreateView(CreateView):
    model = Recipe
    fields = ['title', 'content', 'order']

    success_url = reverse_lazy('recipes:recipes')

    '''def get_success_url(self):
        return reverse("recipes:recipes")
        '''


class RecipeListView(ListView):
    model = Recipe


class RecipeDetailView(DetailView):
    model = Recipe
