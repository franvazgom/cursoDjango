from django.urls import path
from . import views
from .views import RecipeListView, RecipeDetailView, RecipeCreateView, RecipeUpdateView, RecipeDeleteView

recipes_patterns = ([
    path('create/', RecipeCreateView.as_view(), name='create'),
    path('', RecipeListView.as_view(), name='recipes'),
    path('update/<int:pk>/', RecipeUpdateView.as_view(), name='update'),
    path('delete/<int:pk>/', RecipeDeleteView.as_view(), name='delete'),
    path('<int:pk>/<slug:recipe_slug>/',
         RecipeDetailView.as_view(), name='recipe'),
], 'recipes')
