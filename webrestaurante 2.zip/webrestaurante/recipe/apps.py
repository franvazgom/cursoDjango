from django.apps import AppConfig


class RecipeConfig(AppConfig):
    name = 'recipe'
    verbose_name = "Gestor de recetas"
